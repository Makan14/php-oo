<?php

require_once('autoload.php');

$controller = new controller\Controller;

echo '<pre>'; var_dump($controller); echo '</pre>';